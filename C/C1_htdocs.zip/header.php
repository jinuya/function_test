<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http_equiv="X_UA_Compatible" content="IE=edge">
    <meta name="viewport" content="width=device_width, initial_scale=1.0">
    <link rel="stylesheet" href="resources/css/style.css">
    <link rel="stylesheet" href="resources/css/bootstrap.css">
    <link rel="stylesheet" href="resources/fontawesome/css/font-awesome.min.css">
    <script src="resources/js/jquery-3.4.1.min.js"></script>
    <script src="resources/js/bootstrap.js"></script>
    <title>내집꾸미기</title>
</head>

<body>
    <header>
        <nav class="main_nav navbar">
            <a class="navbar_brand px" href="#"><img class="header_logo" src="resources/images/logo.png" alt="logo" title="logo"></a>
            <div class="navbar_collapse">
                <ul class="navbar_nav">
                    <li class="nav_item"><a class="nav_link" href="index.php">홈</a></li>
                    <li class="nav_item"><a class="nav_link" href="#">온라인 집들이</a></li>
                    <li class="nav_item"><a class="nav_link" href="store.php">스토어</a></li>
                    <li class="nav_item"><a class="nav_link" href="#">전문가</a></li>
                    <li class="nav_item"><a class="nav_link" href="#">시공견적</a></li>
                </ul>
                <ul class="login_section">
                    <?php //if(isset($_SESSION['user'])):?>
                        <!-- <p class="main_user">&lt;<?=$_SESSION['user']->user_name?>&gt;(&lt;<?=$_SESSION['user']->user_id?>&gt;)</p> -->
                        <a href="logout" class="main_user">로그아웃</a>
                    <?php //else:?>
                    <li class="nav_item login">
                        <a class="nav_link" href="#">로그인</a>
                    </li>
                    <li class="nav_item account">
                        <a href="#" class="nav_link account_btn">회원가입</a>
                    </li>
                    <?php //endif;?>
                </ul>
            </div>
        </nav>
    </header>