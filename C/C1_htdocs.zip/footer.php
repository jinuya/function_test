<footer>
    Copyright (C) 2020 by MyHome Inc All Rights Reserved.
</footer>
</body>
</html>